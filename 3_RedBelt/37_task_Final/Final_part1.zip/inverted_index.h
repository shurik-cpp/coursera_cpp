#pragma once

#include <istream>
#include <ostream>
#include <set>
#include <list>
#include <vector>
#include <map>
#include <string>
#include <deque>
#include <string_view>

using namespace std;

void RemoveSpaces(string_view& sv);
string_view ReadWord(string_view& sv);
vector<string_view> SplitIntoWords(string_view line);

// Инвертированный индекс (англ. inverted index) — структура данных,
// в которой для каждого слова коллекции документов в соответствующем списке перечислены все документы в коллекции,
// в которых оно встретилось. Инвертированный индекс используется для поиска по текстам.
// https://ru.wikipedia.org/wiki/%D0%98%D0%BD%D0%B2%D0%B5%D1%80%D1%82%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%BD%D1%8B%D0%B9_%D0%B8%D0%BD%D0%B4%D0%B5%D0%BA%D1%81
// https://d3c33hcgiwev3.cloudfront.net/NzvO53CTEei8FQ6TnIKJEA_378a6400709311e8a426e39149140b1f__________-1.pdf?Expires=1639180800&Signature=K8pQ7d-~IJEJkt9G5r-I2YmiozUawfMt-MPWbGbDWwo92Z~gBLTGV4q-t685fMXiQHayJ8MRVdwYe74rCy~LvRZPMAk1tS5wLK-PQkARhslcffSuiBl8ambXwZYkJ~5snTmEWnU9-O7ou-AJ07dBDv39LRc6fGvkv19VxeX2xNA_&Key-Pair-Id=APKAJLTNE6QMUY6HBC5A
class InvertedIndex {
public:
    // конструктор, принимает поток файлов
    InvertedIndex() = default ;
    explicit InvertedIndex(istream& is);

    // вместо лист будет дек
    struct Entry {
        size_t docid;
        size_t rating;
    };
    const vector<Entry>& Lookup(string_view word) const ;

    const deque<string>& GetDocument() const {
        return docs;
    }

private:
    // каждому слову соответствует вектор [id файла и рейтинг в этом файле у этого слова]
    map <string_view, vector<Entry>> index;
    // дек док-ов, нужно добавлять и обращаться к последнему
    deque<string> docs;
};

#include "inverted_index.h"

void RemoveSpaces(string_view& sv) {
    // удаляем лишние пробелы слева
    while (!sv.empty() && isspace(sv[0])) {
        sv.remove_prefix(1);
    }
}
string_view ReadWord(string_view& sv) {
    // ищем и удаляем пробелы
    RemoveSpaces(sv);
    // ищем конец слова
    auto position = sv.find(' ');
    // берем слово
    auto word = sv.substr(0, position);
    // удаляем слово
    sv.remove_prefix(position != sv.npos? position:sv.size() );
    return word;
}

vector<string_view> SplitIntoWords(string_view line) {
    vector<string_view> value;
    // читаем строку - содержимое файла за одну итерацию читаем слово добавляем слово в вектор
    for(string_view word = ReadWord(line); !word.empty() ; word = ReadWord(line)) {
        value.push_back(word);
    }
    return value;
}

InvertedIndex::InvertedIndex(istream& stream) {
    // читаем поток файлов в current_document
    for(string current_document; getline(stream, current_document); ){
        docs.push_back(move(current_document));
        // идентификатор файла, нумерация начинается с 0
        size_t docid = docs.size() - 1;
        // файл теперь в базе и у нас есть его id - читаем из него текст, с помощью SplitIntoWords -
        // она читает последний документ в деке(как раз мы его только что добавили) и возращает vector<string_view>
        for (string_view word : SplitIntoWords(docs.back()) ) {
            // после того как SplitIntoWords вернула нам из документа вектор слов запускаем цикл по обработке каждого слова
            // получаем ссылку на вектор значений для слова
            auto& docids = index[word];
            // если вектор Id/рейтинг не пустой и мы до сих пор в том де файле
            if (!docids.empty() && docids.back().docid == docid ) {
                docids.back().rating++;
            } else {
                docids.push_back({docid, 1});
            }
        }
    }
}

const vector<InvertedIndex::Entry>& InvertedIndex::Lookup(string_view word) const {
    static vector<InvertedIndex::Entry> result;
    if (auto it = index.find(word); it != index.end()) {
        return it->second;
    } else {
        return result;
    }
}
